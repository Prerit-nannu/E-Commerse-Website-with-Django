from django.db import models
from .Catagory import Catagory


class product(models.Model):
    name = models.CharField(max_length=30)
    Price = models.IntegerField()
    Catagory = models.ForeignKey(Catagory, on_delete=models.CASCADE, default=1)
    Description = models.CharField(max_length=200, default='', null=True, blank=True)
    Image = models.ImageField(upload_to='products/')

    @staticmethod
    def get_products_by_id(ids):
        return product.objects.filter(id__in=ids)

    @staticmethod
    def get_all_products():
        return product.objects.all()

    @staticmethod
    def get_all_products_by_Catagoryid(Catagory_id):
        if Catagory_id:
            return product.objects.filter(Catagory=Catagory_id)
        else:
            return product.get_all_products()
