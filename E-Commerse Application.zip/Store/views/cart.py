from django.shortcuts import render, redirect
from Store.Models.Customer import customer
from Store.Models.product import product
from django.views import View

# For cart items
class Cart(View):
    def get(self, request):
      ids = list(request.session.get('cart').keys())
      products = product.get_products_by_id(ids)
      print(products)
      return render(request, 'cart.html', {'products': products})
