from django.shortcuts import render, redirect
from Store.Models.orders import Order
from django.views import View


class Orderview(View):
    def get(self, request):
        customer= request.session.get('Customer')
        orders = Order.get_orders_by_customer(customer)
        print(orders)
        return render(request, 'orders.html', {'orders': orders})
