from django.shortcuts import render, redirect, HttpResponseRedirect
from Store.Models.product import product
from Store.Models.Catagory import Catagory
from django.views import View

class Index(View):
    def post(self, request):
        product = request.POST.get('product')
        remove = request.POST.get('remove')
        cart = request.session.get('cart')
        if cart:
            quantity = cart.get(product)
            if quantity:
                if remove:
                    if quantity<=1:
                        cart.pop(product)
                    else:
                        cart[product] = quantity - 1
                else:
                    cart[product] = quantity +1
            else:
                cart[product] =1
        else:
            cart = {}
            cart[product] = 1

        request.session['cart'] = cart
        print('cart',request.session['cart'])
        return redirect('homepage')

    def get(self , request):
        cart = request.session.get('cart')
        if not cart:
            request.session['cart'] = {}

        products = None
        Catagorys = Catagory.get_all_Catagorys(),
        CatagoryId = request.GET.get('Catagory')
        # return render(request, 'orders/order.html')

        if CatagoryId:
            products = product.get_all_products_by_Catagoryid(CatagoryId);
        else:
            products = product.get_all_products();
        data = {}
        data['products'] = products
        data['Catagorys'] = Catagorys
        print('You are ', request.session.get('email'))
        print('Your ID is ', request.session.get('Customer'))
        return render(request, 'index.html', data)
