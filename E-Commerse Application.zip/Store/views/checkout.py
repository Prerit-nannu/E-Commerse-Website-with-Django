from django.shortcuts import render, redirect
from Store.Models.Customer import customer
from Store.Models.product import product
from Store.Models.orders import Order
from django.views import View


# For Checkout form
class CheckOut(View):
    def post(self, request):
        address = request.POST.get('address')
        phone = request.POST.get('phone')
        customers = request.session.get('Customer')
        cart = request.session.get('cart')
        products = product.get_products_by_id(list(cart.keys()))
        print(address, phone, customers, cart, products)

        for Product in products:
            print(cart.get(str(Product.id)))
            order = Order(customer=customer(id=customers),
                          product=Product,
                          price= Product.Price,
                          address=address,
                          phone=phone,
                          quantity=cart.get(str(Product.id)))

            order.placeOrder()
        request.session['cart'] = {}

        return redirect('homepage')

