from django.contrib import admin
from .Models.product import product
from .Models.Catagory import Catagory
from .Models.Customer import customer
from .Models.orders import Order

class AdminProduct(admin.ModelAdmin):
    list_display = ['name', 'Price', 'Catagory']


class AdminCatagory(admin.ModelAdmin):
    list_display = ['name']

class Admincustomer(admin.ModelAdmin):
    list_display = ['first_name', 'last_name', 'phone', 'email', 'password']

admin.site.register(product, AdminProduct)
admin.site.register(Catagory, AdminCatagory)
admin.site.register(customer)
admin.site.register(Order)